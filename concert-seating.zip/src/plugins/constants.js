const COLUMNS = 10
const ROWS = 10
const GUESTS = 200

export default {
  COLUMNS: COLUMNS,
  ROWS: ROWS,
  GUESTS
}
